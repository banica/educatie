MIT OpenCourseWare is running a program through which users may download a .ZIP file containing all of the HTML pages and files associated with a particular course. Use of the materials included in the .ZIP files are governed by the same Creative Commons use license used for materials published on the MIT OpenCourseWare Web site.


Locating and Using Course Materials


Once you have successfully decompressed and opened the .ZIP file, use your browser to open the HTML homepage of the MIT OpenCourseWare course. It can be found in the following directory: /CourseNumberTermYear/OcwWeb/Department/CourseNumberTermYear/CourseHome/index.htm.

Examples:

/10-450Process-Dynamics--Operations-and-ControlSpring2003/OcwWeb/Chemical-Engineering/ 10-450Process-Dynamics--Operations-and-ControlSpring2003/CourseHome/index.htm

/21A-100Fall2004/OcwWeb/Anthropology/ 21A-100Fall2004/CourseHome/index.htm

Whether you are using MIT OpenCourseWare materials online, or offline after you have downloaded a .ZIP version of the course, please read the MIT OpenCourseWare use license on the MIT OpenCourseWare site at http://ocw.mit.edu/OcwWeb/web/terms/terms/index.htm and included in this package to ensure you are complying with the terms-of-use requirements for MIT OpenCourseWare materials.

Note: To easily access the home page of the downloaded course in the future, make a shortcut to the index.htm file on your desktop or elsewhere on your computer.


Frequently Asked Questions:


1) Why are some materials such as video lectures or media simulations missing from the .ZIP file?

Some materials, such as videos, java applets, and other special content is not posted on the MIT OpenCourseWare server, but linked to rather than included in the .ZIP file. This prevents .ZIP files from growing too large for download. You may view the entire MIT OpenCourseWare course site - and download these associated files - by clicking on the course homepage in the .ZIP file. To download MIT OpenCourseWare videos to your desktop, please read the Download FAQ on the MIT OpenCourseWare Web site at http://ocw.mit.edu/OcwWeb/web/help/faq4/index.htm#3.

2) Whom do I contact if I have a problem downloading a course?

Send an email to the MIT OpenCourseWare Team via our Feedback Form http://ocw.mit.edu/OcwWeb/jsp/feedback.jsp?Referer=ZIP or email ocw@mit.edu.
