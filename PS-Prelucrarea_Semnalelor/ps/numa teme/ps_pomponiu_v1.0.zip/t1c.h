// Matrici imagine
extern	float			**r;
extern	float			**g;
extern	float			**b;	

// Dimensiune imagine
extern	unsigned short	dx;
extern	unsigned short	dy;

// Proceduri compresie Huffman
extern	void scrie_bit(char bit);
extern	void scrie_clasa(int nz,int mag,int tip);
extern  void descarca_biti(void);
