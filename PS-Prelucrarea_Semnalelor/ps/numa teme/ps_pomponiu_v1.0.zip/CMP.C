#include "t1c.h"
#include <math.h>
#include <stdio.h>
#define     PI     3.1415
// Matrici de cuantizare

// Matrice pentru cuantizare componenta Y compresie buna
float	qy0[8][8]={			{   8,   5,   6,   7,  10,  16,  25,  33 },
					{   5,   6,   6,   9,  12,  23,  31,  36 },
					{   6,   6,   8,  11,  19,  28,  36,  37 },
					{   7,   9,  11,  14,  26,  37,  41,  40 },
					{  10,  12,  19,  26,  34,  47,  51,  47 },
					{  16,  23,  28,  37,  47,  52,  58,  48 },
					{  25,  31,  36,  41,  51,  58,  60,  51 },
					{  33,  36,  37,  40,  47,  48,  51,  49 } };

// Matrice pentru cuantizare componenta Y calitate buna
float	qy1[8][8]={			{  16,  11,  12,  15,  21,  32,  50,  66 },
					{  11,  12,  13,  18,  24,  46,  62,  73 },
					{  12,  13,  16,  23,  38,  56,  73,  75 },
					{  15,  18,  23,  29,  53,  75,  83,  80 },
					{  21,  24,  38,  53,  68,  95, 103,  94 },
					{  32,  46,  56,  75,  95, 104, 117,  96 },
					{  50,  62,  73,  83, 103, 117, 120, 102 },
					{  66,  73,  75,  80,  94,  96, 102,  99 } };

// Matrice pentru cuantizare componenta U si V compresie buna
float	qc0[8][8]={			{   8,   9,  12,  23,  49,  49,  49,  49 },
					{   9,  10,  13,  33,  49,  49,  49,  49 },
					{  12,  13,  28,  49,  49,  49,  49,  49 },
					{  23,  33,  49,  49,  49,  49,  49,  49 },
					{  49,  49,  49,  49,  49,  49,  49,  49 },
					{  49,  49,  49,  49,  49,  49,  49,  49 },
					{  49,  49,  49,  49,  49,  49,  49,  49 },
					{  49,  49,  49,  49,  49,  49,  49,  49 } };

// Matrice pentru cuantizare componenta U si V calitate buna
float	qc1[8][8]={			{  17,  18,  24,  47,  99,  99,  99,  99 },
					{  18,  21,  26,  66,  99,  99,  99,  99 },
					{  24,  26,  56,  99,  99,  99,  99,  99 },
					{  47,  66,  99,  99,  99,  99,  99,  99 },
					{  99,  99,  99,  99,  99,  99,  99,  99 },
					{  99,  99,  99,  99,  99,  99,  99,  99 },
					{  99,  99,  99,  99,  99,  99,  99,  99 },
					{  99,  99,  99,  99,  99,  99,  99,  99 } };

//Matricea de conversie de culoare   :[r, g, b]->[y, u, v]
//float   C[3][3]={ 			{ 0.3,    0.59,     0.11 },
//					{ 0.5,   -0.42,    -0.08 },
//					{-0.17,  -0.33,     0.5	 }   };

//Matricea de codificare (Z)
int Z[8][8]={           {  0,   1,   5,   6,   14,   15,   27,   28 },
			{  2,   4,   7,   13,  16,   26,   29,   42 },
			{  3,   8,   12,  17,  25,   30,   41,   43 },
			{  9,   11,  18,  24,  31,   40,   44,   53 },
			{  10,  19,  23,  32,  39,   45,   52,   54 },
			{  20,  22,  33,  38,  46,   51,   55,   60 },
			{  21,  34,  37,  47,  50,   56,   59,   62 },
			{  35,  36,  48,  49,  57,   58,   61,   63 }    };



int magnit(int x)
{
	int mag ;
	if(x==-1 || x==1)
		mag = 1 ;
	else
		if(x==-3 || x==-2 || x==2 || x==3)
			mag = 2 ;
		else 
			if((x>=-7 && x<=-4) || (x>=4 && x<=7))
				mag = 3 ;
			else
				if((x>=-15 && x<=-8) || (x>=8 && x<=15))
					mag = 4 ;
				else
					if((x>=-31 && x<=-16) || (x>=16 && x<=31))
						mag = 5 ;
					else
						if((x>=-63 && x<=-32) || (x>=32 && x<=63))
							mag = 6 ;
						else
							if((x>=-127 && x<=-64) || (x>=64 && x<=127))
								mag = 7 ;
							else
								if((x>=-254 && x<=-128) || (x>=128 && x<=254))
									mag = 8 ;
								else
									if((x>=-511 && x<=-255) || (x>=255 && x<=511))
										mag = 9 ;
									else
										if((x>=-1023 && x<=-512) || (x>=512 && x<=1023))
											mag = 10;
	return mag ;
}

void comprima(void)
{


	//Matricia rezultata dupa cuantizare
	float  X[8][8] ;

	// Matricea transf. DCT si matricile ajutatoare
	float h[8][8], A[8][8], B[8][8], D[8][8], T[8][8], P[8][8] ;

	//Vectorul codificarii
	short int cod1[64], cod2[64], cod3[64] ;

	int i, j, a = 0, l, k, e, n, mag, x, masc ;

	//variabile temporare
	float y = 0, u = 0 ;
	
	printf("Cuantizare: \n1:compresia buna\n0:calitate buna\n") ;
	scanf("%d", &a) ;

	//Generarea matricii H
	for (i = 0; i <8; i++)
		for(j = 0; j < 8; j++)
			if ( i == 0 )
				h[i][j] = 1/(2 * sqrt(2)) ;
			else
				h[i][j] = 0.5 * cos((i * (2*j + 1) * PI)/16) ;

//Pas 1:conversia de culoare

	//Calcularea matricilor y, u, v in matricile r, g, b

	for (i = 0; i < dx; i++)
		for(j = 0; j < dy; j++)
		{
			 y = 0.3 * r[i][j] + 0.59 * g[i][j] + 0.11 * b[i][j] ;
			 u = 0.5 * r[i][j] - 0.42 * g[i][j] - 0.08 * b[i][j] ;
			 b[i][j] =-0.17 * r[i][j] - 0.33 * g[i][j] + 0.5 * b[i][j] ;
			 r[i][j] = y ;
			 g[i][j] = u ;
		}


//Extragerea, dim maticile r, g, b, de blocuri de dim. 8x8

for(k = 0; k < dx/8; k++)
	for (l = 0; l < dy/8; l++)
	{
		for(i = 0 ; i < 8 ; i++)
			for(j = 0; j < 8; j++) 
			{
				A[i][j] = r[8*k+i][8*l+j] ;
				B[i][j] = g[8*k+i][8*l+j] ;
				D[i][j] = b[8*k+i][8*l+j] ;
			}

//Pas 2:  Transformarea   DCT

	//Aplicare DCT
		for (i = 0; i < 8; i++)
			for(j = 0; j < 8; j++)
			{
				X[i][j] = h[i][j] * A[i][j] * h[j][i] ;
				T[i][j] = h[i][j] * B[i][j] * h[j][i] ;
				P[i][j] = h[i][j] * D[i][j] * h[j][i] ;
			}

//Pas 3: Cuantizarea
		for (i = 0; i < 8; i++)
			for(j = 0; j < 8; j++)
				if(a == 0)
				{
					if (X[i][j] >= 0)
						X[i][j] = floor(0.5 + X[i][j]/qy0[i][j]) ;
					else
						X[i][j] = floor(0.5 - X[i][j]/qy0[i][j]) ;
					if (T[i][j] >= 0)
						T[i][j] = floor(0.5 + T[i][j]/qc0[i][j]) ;
					else
						T[i][j] = floor(0.5 - T[i][j]/qc0[i][j]) ;
					if (P[i][j] >= 0)
						P[i][j] = floor(0.5 + P[i][j]/qc0[i][j]) ;
					else
						P[i][j] = floor(0.5 - P[i][j]/qc0[i][j]) ;
				}
				else
				{
					if (X[i][j] >= 0)
						X[i][j] = floor(0.5 + X[i][j]/qy1[i][j]) ;
					else
						X[i][j] = floor(0.5 - X[i][j]/qy1[i][j]) ;
					if (T[i][j] >= 0)
						T[i][j] = floor(0.5 + T[i][j]/qc1[i][j]) ;
					else
						T[i][j] = floor(0.5 - T[i][j]/qc1[i][j]) ;
					if (P[i][j] >= 0)
						P[i][j] = floor(0.5 + P[i][j]/qc1[i][j]) ;
					else
						P[i][j] = floor(0.5 - P[i][j]/qc1[i][j]) ;
				}

//Pas 4: Codificarea

		for (i = 0; i < 8; i++)
			for(j = 0; j < 8; j++)
					{
						e = Z[i][j] ;
						cod1[e] = X[i][j] ;
						cod2[e] = T[i][j] ;
						cod3[e] = P[i][j] ;
					}

/*
			printf("\nPrimul vector[%d %d]:",k,l);
			for(e=0;e<=63;e++)
				printf("%d ",cod1[e]);
			printf("\nAl doilea vector[%d %d]:",k,l);
			for(e=0;e<=63;e++)
				printf("%d ",cod2[e]);
			printf("\nAl treilea vector[%d %d]:",k,l);
			for(e=0;e<=63;e++)
				printf("%d ",cod3[e]);
*/
			
		//Prelucrarii asupra vect. cod1,2,3-aflarea End Of Block(EOB)

		/*for(y=63;y && cod1[y]==0; y--);*/
				
		for (i = 63; i > 0; i--)
			if ( cod1[i] != 0 ) 
				break;
		y = i ;  //EOB pentru cod1

		for (i = 63; i > 0; i--)
			if ( cod2[i] != 0 )
				break;
		u = i ;   //EOB pentru cod2 

		for (i = 63; i > 0; i--)
			if ( cod3[i] != 0 )
				break ;
		e = i ;   //EOB pentru cod3

		for(i=0,n=0; i <= y; i++)
			if(cod1[i] == 0)
			{
				n++ ;
				if(n==16)
				{
					mag = 0 ;
					scrie_clasa(15, 0, 0) ;
					n = 0 ;
				}
			}
			else 
			{	
				x = cod1[i] ;
				
				//calculeaza magnitudinea
				mag = magnit(x); 
				
				
				//scrie clasa
				scrie_clasa( n, mag, 0);
				n = 0 ;
				
				//scrie valoarea
				if(x > 0)
				{
					for ( masc=1<<(mag-1);masc!=0;masc>>=1)
						scrie_bit((masc&x)!=0); //diferit de zero pentru a se evita trunchierea la char

					/*
					varianta
					  
					masc = 1 << (mag - 1) ;   //masca initiala
					for (j=1; j<=mag; j++)
					{	
						bit = masc & x ;
						scrie_bit(bit) ;
						masc = masc >> 1 ;
					}
					*/

				}
				else
				{
					x = x-1 ;
					for ( masc=1<<(mag-1);masc!=0;masc>>=1)
						scrie_bit((masc&x)!=0); //diferit de zero pentru a se evita trunchierea la char
				}
			}
		if (i<=63) scrie_clasa(0,0,0); //end of block

		for(i=0,n=0; i <= u; i++)
			if(cod2[i] == 0)
			{
				n++;
				if(n==16)
				{
					mag = 0 ;
					scrie_clasa (15,0,1) ;
					n = 0 ;
				}
			}
			else 
			{					
				x = cod2[i] ;
				mag = magnit(x) ;																
				scrie_clasa( n, mag, 1);
				n = 0 ;
				if(x > 0)
				{
					
					for ( masc=1<<(mag-1);masc!=0;masc>>=1)
						scrie_bit((masc&x)!=0); //diferit de zero pentru a se evita trunchierea la char

				}
				else
				{
					x = x-1 ;
					for ( masc=1<<(mag-1);masc!=0;masc>>=1)
						scrie_bit((masc&x)!=0); //diferit de zero pentru a se evita trunchierea la char
				}
					
			}

		if (i<=63) scrie_clasa(0,0,1); //end of block
		
		for(i=0,n=0; i <= e; i++)
			if(cod3[i] == 0)
			{	
				n++;
				if(n==16)
				{	
					mag = 0 ;
					scrie_clasa(15,0,1) ;
					n = 0;	
				}
			}
			else 
			{	
				x = cod3[i] ;
				mag = magnit(x) ;																
				scrie_clasa( n, mag, 1);
				n = 0 ;
				if(x > 0)
				{
					for ( masc=1<<(mag-1);masc!=0;masc>>=1)
						scrie_bit((masc&x)!=0); //diferit de zero pentru a se evita trunchierea la char


				}
				else
				{
					x = x-1 ;
					for ( masc=1<<(mag-1);masc!=0;masc>>=1)
						scrie_bit((masc&x)!=0); //diferit de zero pentru a se evita trunchierea la char
				}
			}

		if (i<=63) scrie_clasa(0,0,1); //end of block
	}	
	
	descarca_biti();//ultimii biti....

}

